const $config = {
    API_BASE_URL : "https://myfitnessapp-api.umfahrer.dev/api/", // LIVE
    //API_BASE_URL :  "https://myfitnessappapi.loc/api/" // DEV
};

export default $config;

  