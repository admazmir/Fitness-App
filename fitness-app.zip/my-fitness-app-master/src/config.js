var config = {
    API_BASE_URL : "https://myfitnessapp-api.umfahrer.dev/api/", // LIVE
    //API_BASE_URL :  "https://myfitnessapp-api.loc/api/" // DEV
}; 

export { config };
  